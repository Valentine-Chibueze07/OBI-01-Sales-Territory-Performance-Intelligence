# OBI-01 — Data Architecture & Validation Notes

## Project
Sales & Territory Performance Intelligence

## Dataset status
This is an engineered synthetic dataset designed to simulate a Nigerian lubricant distribution business. It is not sourced from, and must not be represented as, the actual records of a named company. Its operational patterns, product catalogue, transaction values, customer names and performance outcomes are illustrative.

The raw layer intentionally contains controlled data-quality defects for cleaning and validation practice. The curated layer contains records that passed the documented checks; unresolved or invalid records are retained in the quarantine folder.

## Reporting period
1 November 2024 to 31 October 2026 (24 complete months). The calendar dimension extends through 30 November 2026 to cover return dates recorded up to 30 days after the final transaction date.

## Table grain
- Sales_Transactions: one row per product line on an order.
- Sales_Activities: one row per recorded sales activity.
- Sales_Targets: one row per territory per reporting month.
- Returns_Transactions: one row per return record linked to an original transaction line.
- Master tables: one row per unique business entity.
- Date_Dimension: one row per calendar date.

## Important business rules
1. Net_Sales_NGN is recognised only for Delivered orders. Pending and Cancelled orders carry zero recognised net sales in this model.
2. Gross_Sales_NGN = Quantity_Sales_Units × Unit_Price_NGN.
3. Net_Sales_NGN = Gross_Sales_NGN − Discount_Amount_NGN for Delivered orders.
4. Blank discount amounts in the raw synthetic source are treated as zero only because this simulated source-system convention defines a blank discount as “no discount”. This must be validated with a real source-system owner before applying to live data.
5. Product pack sizes are retained. Standardised physical volume can be derived using Quantity_Sales_Units × Litres_or_KG_Per_Unit, but litres and kilograms must not be combined into one physical-volume KPI without conversion/segmentation.
6. Sales_Activities records are not proof of a successful sale. A linked order and a clearly defined attribution window are needed for defensible visit-to-order conversion.
7. Return_Value_NGN is recorded separately. Net sales after returns must be calculated by linking approved returns to original transaction lines; do not subtract pending returns.
8. A populated Linked_Order_ID on a sales activity is restricted to a delivered order for the same customer occurring within 30 days after the activity date. An activity marked Order Generated may still have no linked order where no qualifying transaction exists; do not count it as an attributed conversion without a link.
9. Customer phone numbers are optional contact fields and are not fabricated when missing.
8. Customer phone numbers are optional contact fields and are not fabricated when missing.
10. Sales target values are synthetic planning assumptions, not actual company targets.
11. Territory/customer/representative assignments are internally aligned in curated transaction and activity data.

## Data quality treatment
- Duplicate primary keys: first occurrence retained; duplicates logged.
- Inconsistent category/status casing and whitespace: standardised.
- Missing discount: set to zero under the explicit synthetic-source assumption above.
- Missing phone numbers and optional follow-up dates: retained as null where appropriate.
- Invalid foreign keys: moved to quarantine and excluded from curated fact tables.
- Territory assignment mismatches: quarantined.
- Unmatched optional linked order references: cleared from the optional link field and logged.
- Transaction arithmetic: gross and net sales recalculated from quantity, unit price, discount and order status.

## Modelling notes
- Use a star-schema approach for the sales transaction fact.
- Sales_Activities is a separate fact table; avoid joining it directly to transaction lines in a way that multiplies sales values.
- Sales_Targets is a monthly fact table and must relate to the unique Month_Dimension table. The daily Date_Dimension also relates to Month_Dimension through Year_Month.
- Returns_Transactions is a separate fact table at return-record grain and should be aggregated to transaction line/order grain before joining to sales measures.
- Customer and representative territory assignments are single-valued in this dataset. A real organisation may require effective-dated territory assignments.

## Not yet performed
No analytical conclusions, performance rankings, forecasting, dashboard development or business recommendations have been produced. Those belong to Phase 3 and Phase 4 after the Phase 2 data package is reviewed and approved.
