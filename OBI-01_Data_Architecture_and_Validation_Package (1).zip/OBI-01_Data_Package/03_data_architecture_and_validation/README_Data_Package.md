# OBI-01 — Sales & Territory Performance Intelligence

## Package contents
- `01_raw_source_files/` — simulated source extracts with controlled data-quality imperfections.
- `02_validated_curated_files/` — cleaned and validated tables for the next analytical phase.
- `03_data_architecture_and_validation/` — data dictionary, relationship map, issue log, validation summary and assumptions.
- `04_quarantined_records/` — invalid records held outside the curated analytical tables.

## Important disclosure
All records are engineered synthetic data. They are designed to be operationally plausible for a Nigerian lubricant distribution business, but they are not actual company records or evidence of real-world company performance. Do not present synthetic findings as actual company results.

## Reporting period
1 November 2024 to 31 October 2026.

## Recommended review sequence
1. Read `03_data_architecture_and_validation/Architecture_and_Assumptions.md`.
2. Review `Relationship_Map.csv`.
3. Review `Data_Dictionary.csv`.
4. Compare raw and curated row counts in `Validation_Summary.csv`.
5. Inspect the issue log and quarantined records.
6. Approve the data model and CSV package before Phase 3.

## Grain and modelling cautions
Sales transactions are at product-line grain. Activities, monthly targets and returns are separate fact tables. Do not join all fact tables directly at row level because this can multiply measures. Use conformed dimensions and aggregate facts to the required grain before combining measures.
